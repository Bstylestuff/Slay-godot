# chart-gd

Tested on Godot Engine 3.1. For Godot engine 2.1 please use the branch [2.1](https://github.com/binogure-studio/chart-gd/tree/2.1)

## Preview

![Demo](./assets/charts.gif "Example")

## Usage

See example

# License

See [License file](./LICENSE)